When I switched from Unity to Godot, one of the things I noticed Unity did better immediately was the placeholder sprites. You could make geometry 2D sprites easily for prototyping. Meanwhile in Godot, not only are there no basic sprites for you to use, but you also have to add the collision and physics yourself. 

Here are a handful of simple geometrical shapes you can put into 2D sprites for prototyping your games. 
